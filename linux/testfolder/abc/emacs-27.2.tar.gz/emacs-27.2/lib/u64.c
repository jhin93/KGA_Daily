#include <config.h>
#define _GL_U64_INLINE _GL_EXTERN_INLINE
#include "u64.h"
typedef int dummy;
